package com.omega.assistant

import java.util.Locale

object Advice {
 fun reply(message:String):String {
  val q=message.lowercase(Locale.ROOT)
  return when {
   listOf("safe","zona","gás").any { it in q } -> "Observe o tempo da zona e a rota mais segura. Priorize cobertura e não espere o último segundo."
   listOf("vida","kit","inalador","cura").any { it in q } -> "Procure cobertura antes de curar. Verifique se há inimigos próximos e planeje uma rota de fuga."
   listOf("arma","rush","sniper","rifle").any { it in q } -> "Compare alcance e cadência: curta distância favorece armas rápidas; distância longa exige controle e posicionamento."
   listOf("carro","veículo","dirigir").any { it in q } -> "Veículos ajudam em rotações longas, mas chamam atenção. Planeje onde abandonar o veículo."
   listOf("granada","gel","habilidade").any { it in q } -> "Considere cobertura, tempo de ativação e posição antes de gastar recursos."
   else -> "Entendi. Conte a situação da partida (vida, posição, equipamento e objetivo) para eu sugerir uma estratégia. Esta versão não vê o jogo automaticamente."
  }
 }
}
