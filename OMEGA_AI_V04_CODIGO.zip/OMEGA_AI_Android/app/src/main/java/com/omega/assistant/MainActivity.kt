package com.omega.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32) }
  root.addView(TextView(this).apply { text="OMEGA AI • Android\nAssistente flutuante experimental\n\nSem root, sem login e sem API paga.\nNão controla partidas automaticamente."; textSize=20f })
  root.addView(Button(this).apply { text="1. Autorizar sobreposição"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  root.addView(Button(this).apply { text="2. Iniciar bolinha OMEGA"; setOnClickListener {
   if (Settings.canDrawOverlays(this@MainActivity)) startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
   else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
  } })
  root.addView(Button(this).apply { text="3. Capturar tela real"; setOnClickListener { startActivity(Intent(this@MainActivity, CaptureActivity::class.java)) } })
  root.addView(Button(this).apply { text="4. Abrir cérebro de decisões (manual)"; setOnClickListener { startActivity(Intent(this@MainActivity, BrainActivity::class.java)) } })
  root.addView(Button(this).apply { text="Parar OMEGA"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } })
  setContentView(root)
 }
}
