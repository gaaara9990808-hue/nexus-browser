package com.omega.assistant

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
 private lateinit var wm: WindowManager
 private var bubble: View? = null
 private var panel: View? = null
 private val overlayType get() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 override fun onBind(intent: Intent?): IBinder? = null
 override fun onCreate() {
  super.onCreate()
  val channel = "omega_overlay"
  val manager = getSystemService(NotificationManager::class.java)
  manager.createNotificationChannel(NotificationChannel(channel,"OMEGA em execução",NotificationManager.IMPORTANCE_LOW))
  val intent = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)
  val notification = Notification.Builder(this,channel).setContentTitle("OMEGA AI ativa").setContentText("Toque para abrir os controles").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(intent).build()
  startForeground(1,notification)
  wm = getSystemService(WINDOW_SERVICE) as WindowManager
  createBubble()
 }
 private fun bg(color:Int,radius:Float=30f)=GradientDrawable().apply { setColor(color); cornerRadius=radius }
 private fun params(w:Int,h:Int,x:Int,y:Int)=WindowManager.LayoutParams(w,h,overlayType,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; this.x=x; this.y=y }
 private fun createBubble() {
  val view=TextView(this).apply { text="Ω"; textSize=28f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=bg(Color.rgb(54,65,110),100f) }
  val size=(62*resources.displayMetrics.density).toInt()
  val lp=params(size,size,15,220)
  wm.addView(view,lp); bubble=view
  var downX=0f; var downY=0f; var startX=0; var startY=0; var moved=false
  view.setOnTouchListener { _, event ->
   when(event.action) {
    MotionEvent.ACTION_DOWN -> { downX=event.rawX; downY=event.rawY; startX=lp.x; startY=lp.y; moved=false; true }
    MotionEvent.ACTION_MOVE -> { val dx=event.rawX-downX; val dy=event.rawY-downY; if(kotlin.math.abs(dx)>10 || kotlin.math.abs(dy)>10) moved=true; lp.x=startX+dx.toInt(); lp.y=startY+dy.toInt(); wm.updateViewLayout(view,lp); true }
    MotionEvent.ACTION_UP -> { if(!moved) togglePanel(); true }
    else -> false
   }
  }
 }
 private fun togglePanel() {
  if(panel!=null) { wm.removeView(panel); panel=null; return }
  val density=resources.displayMetrics.density
  val container=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); background=bg(Color.rgb(22,27,42),22f) }
  fun text(s:String,sz:Float=15f)=TextView(this).apply { text=s; textSize=sz; setTextColor(Color.WHITE); setPadding(4,8,4,8) }
  container.addView(text("Ω OMEGA AI • Assistente",19f))
  val history=TextView(this).apply { text="Digite uma situação ou peça uma dica.\nNão há leitura automática da tela nesta versão."; setTextColor(Color.LTGRAY); textSize=14f; setPadding(4,10,4,10) }
  val scroll=ScrollView(this).apply { addView(history) }
  container.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  val entry=EditText(this).apply { hint="Ex.: pouca vida, safe fechando"; setSingleLine(false); maxLines=3; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
  container.addView(entry)
  container.addView(Button(this).apply { text="Pedir dica"; setOnClickListener { val q=entry.text.toString().trim(); if(q.isNotEmpty()) { history.append("\n\nVocê: $q\nOMEGA: ${Advice.reply(q)}"); entry.text.clear() } } })
  container.addView(Button(this).apply { text="Minimizar"; setOnClickListener { togglePanel() } })
  container.addView(Button(this).apply { text="Parar OMEGA"; setOnClickListener { stopSelf() } })
  val lp=params((310*density).toInt(),(420*density).toInt(),(20*density).toInt(),(120*density).toInt())
  lp.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
  lp.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
  wm.addView(container,lp); panel=container
 }
 override fun onDestroy() { panel?.let { wm.removeView(it) }; bubble?.let { wm.removeView(it) }; panel=null; bubble=null; super.onDestroy() }
}
