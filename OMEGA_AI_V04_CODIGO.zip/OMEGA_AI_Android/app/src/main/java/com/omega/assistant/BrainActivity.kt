package com.omega.assistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

/** Interactive, offline policy sandbox. Input is user-provided; never pretends to read the game. */
class BrainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,36,28,36) }
        scroll.addView(root)
        fun title(s:String) { root.addView(TextView(this).apply { text=s; textSize=19f; setTextColor(Color.BLACK) }) }
        fun toggle(s:String, default:Boolean=false): CheckBox = CheckBox(this).apply { text=s; isChecked=default; root.addView(this) }
        fun number(s:String, initial:Int): EditText {
            title(s)
            return EditText(this).apply { inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED; setText(initial.toString()); root.addView(this) }
        }
        title("OMEGA • Cérebro de sobrevivência")
        root.addView(TextView(this).apply { text="Simulador autônomo de decisões. Informe o estado da partida manualmente; NÃO controla nem lê Free Fire." })
        val hp = number("Vida (0–100)", 100)
        val distance = number("Distância do inimigo em metros (-1 = nenhum)", -1)
        val ammo = number("Munição", 30)
        val kits = number("Kits", 2)
        val inhalers = number("Inaladores", 1)
        val gels = number("Paredes de gel", 2)
        val outside = toggle("Fora da safe")
        val closing = toggle("Safe fechando")
        val cover = toggle("Estou em cobertura")
        val vehicle = toggle("Veículo disponível")
        val longRange = toggle("Tenho arma de longo alcance")
        val ability = toggle("Habilidade defensiva pronta")
        val result = TextView(this).apply { textSize=19f; setPadding(0,20,0,20) }
        fun read(e:EditText, fallback:Int) = e.text.toString().toIntOrNull() ?: fallback
        fun update() {
            val state = GameState(
                hp=read(hp,100).coerceIn(0,100), enemyDistance=read(distance,-1),
                ammo=read(ammo,30).coerceAtLeast(0), medkits=read(kits,0).coerceAtLeast(0),
                inhalers=read(inhalers,0).coerceAtLeast(0), glooWalls=read(gels,0).coerceAtLeast(0),
                outsideSafe=outside.isChecked, safeClosing=closing.isChecked,
                cover=cover.isChecked, vehicle=vehicle.isChecked,
                longRangeWeapon=longRange.isChecked, abilityReady=ability.isChecked
            )
            val d = SurvivalBrain.decide(state)
            result.text="PRIORIDADE ${d.priority}\n${d.action}\n\n${d.reason}"
        }
        root.addView(Button(this).apply { text="Analisar situação"; setOnClickListener { update() } })
        root.addView(Button(this).apply { text="Teste: perigo e vida baixa"; setOnClickListener {
            hp.setText("25"); distance.setText("10"); outside.isChecked=false; update()
        } })
        root.addView(Button(this).apply { text="Teste: fora da safe"; setOnClickListener {
            hp.setText("80"); distance.setText("-1"); outside.isChecked=true; update()
        } })
        root.addView(result)
        update()
        setContentView(scroll)
    }
}
