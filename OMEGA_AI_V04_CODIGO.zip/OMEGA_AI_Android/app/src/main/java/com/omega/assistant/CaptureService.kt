package com.omega.assistant

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

/** Captura única; encerra projeção e serviço após gravar PNG privado. */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channel = "omega_capture"
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"OMEGA Captura",NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("OMEGA capturando tela").build()
        startForeground(22,notification)
        try {
            val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
            @Suppress("DEPRECATION")
            val resultData = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java) else intent?.getParcelableExtra<Intent>("resultData")
            if (resultData == null || resultCode != Activity.RESULT_OK) { stopSelf(); return START_NOT_STICKY }
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode,resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { cleanup() }
            },handler)
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            val width=metrics.widthPixels; val height=metrics.heightPixels
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2)
            display=projection?.createVirtualDisplay("OMEGA_CAPTURE",width,height,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
            reader?.setOnImageAvailableListener({ source ->
                val image=source.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane=image.planes[0]
                    val paddedWidth=width+plane.rowStride/plane.pixelStride-width
                    val bmp=Bitmap.createBitmap(width+paddedWidth,height,Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    val cropped=Bitmap.createBitmap(bmp,0,0,width,height)
                    FileOutputStream(File(filesDir,"omega-last-capture.png")).use { cropped.compress(Bitmap.CompressFormat.PNG,100,it) }
                    cropped.recycle(); bmp.recycle()
                } finally { image.close(); cleanup(); stopSelf() }
            },handler)
            handler.postDelayed({ cleanup(); stopSelf() },5000)
        } catch (e: Exception) { android.util.Log.e("OMEGA","Falha ao capturar",e); cleanup(); stopSelf() }
        return START_NOT_STICKY
    }
    private fun cleanup() {
        reader?.setOnImageAvailableListener(null,null)
        display?.release(); display=null
        reader?.close(); reader=null
        val p=projection; projection=null; p?.stop()
    }
    override fun onDestroy() { cleanup(); super.onDestroy() }
}
