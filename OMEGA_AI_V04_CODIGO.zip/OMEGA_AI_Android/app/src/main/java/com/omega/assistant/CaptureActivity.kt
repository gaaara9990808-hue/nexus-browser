package com.omega.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.io.File
import java.io.FileOutputStream

/** Captura uma imagem REAL da tela após consentimento explícito do usuário. */
class CaptureActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private val requestCode = 402
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 36, 24, 24) }
        root.addView(TextView(this).apply { text = "OMEGA • Captura real da tela"; textSize = 23f; setTextColor(Color.BLACK) })
        status = TextView(this).apply { text = "A captura exige permissão do Android. Nenhuma imagem é enviada à internet."; textSize = 16f }
        root.addView(status)
        root.addView(Button(this).apply { text = "Autorizar e capturar tela"; setOnClickListener { requestCapture() } })
        preview = ImageView(this).apply { adjustViewBounds = true }
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Voltar"; setOnClickListener { finish() } })
        setContentView(root)
    }
    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
    }
    @Deprecated("Activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != this.requestCode || resultCode != RESULT_OK || data == null) {
            status.text = "Captura não autorizada."
            return
        }
        // Android 14+ exige um serviço foreground do tipo mediaProjection antes de getMediaProjection.
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra("resultCode", resultCode)
            putExtra("resultData", data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        status.text = "Capturando tela real… aguarde alguns segundos."
        handler.postDelayed({
            val file = File(filesDir, "omega-last-capture.png")
            if (file.exists()) {
                preview.setImageBitmap(android.graphics.BitmapFactory.decodeFile(file.absolutePath))
                status.text = "Imagem real salva: ${file.absolutePath}"
            } else status.text = "Ainda sem imagem. Tente novamente e confira a permissão."
        }, 3500)
    }
}
