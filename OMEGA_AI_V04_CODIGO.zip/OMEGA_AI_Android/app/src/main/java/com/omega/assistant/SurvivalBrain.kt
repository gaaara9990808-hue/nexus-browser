package com.omega.assistant

/** Deterministic autonomous survival policy. No access to game memory or controls. */
data class GameState(
    val hp: Int = 100,
    val safeClosing: Boolean = false,
    val outsideSafe: Boolean = false,
    val enemyDistance: Int = -1,
    val cover: Boolean = false,
    val medkits: Int = 2,
    val inhalers: Int = 1,
    val glooWalls: Int = 2,
    val vehicle: Boolean = false,
    val ammo: Int = 30,
    val longRangeWeapon: Boolean = false,
    val abilityReady: Boolean = false
)

data class Decision(val action: String, val reason: String, val priority: Int)

object SurvivalBrain {
    fun decide(s: GameState): Decision {
        val enemy = s.enemyDistance >= 0
        val close = enemy && s.enemyDistance < 25
        val far = enemy && s.enemyDistance >= 75
        return when {
            s.outsideSafe && s.hp < 35 -> Decision("ROTACIONAR PARA SAFE", "Zona causando risco crítico: evitar confrontos e procurar rota segura.", 100)
            close && s.hp < 45 && s.glooWalls > 0 -> Decision("COBERTURA / GEL", "Ameaça próxima com vida baixa: interromper exposição.", 96)
            close && s.hp < 45 -> Decision("RECUAR", "Vida baixa: priorizar distância e obstáculos.", 94)
            s.outsideSafe -> Decision(if (s.vehicle) "USAR VEÍCULO PARA SAFE" else "CORRER PARA SAFE", "Priorizar zona segura antes de procurar combate.", 90)
            s.hp <= 55 && s.cover && s.medkits > 0 -> Decision("USAR KIT", "Há cobertura e a vida está baixa.", 86)
            s.hp <= 75 && !enemy && s.inhalers > 0 -> Decision("USAR INALADOR", "Sem inimigo visível, oportunidade de recuperar recursos.", 78)
            close && s.abilityReady -> Decision("ATIVAR HABILIDADE DEFENSIVA", "Inimigo próximo: criar vantagem para escapar.", 77)
            close && s.ammo == 0 -> Decision("RECUAR E RECARREGAR", "Sem munição, evitar confronto.", 76)
            close -> Decision("DEFENDER E BUSCAR COBERTURA", "Evitar rush; reagir apenas se necessário.", 70)
            s.safeClosing -> Decision("PLANEJAR ROTA PARA SAFE", "Antecipar fechamento e evitar campo aberto.", 65)
            far && !s.longRangeWeapon -> Decision("EVITAR TROCA À DISTÂNCIA", "Arma inadequada para alvo distante.", 60)
            far -> Decision("OBSERVAR SEM SE EXPOR", "Evitar disparos desnecessários e preservar posição.", 55)
            s.hp <= 55 && s.medkits > 0 -> Decision("PROCURAR COBERTURA PARA CURAR", "Não curar em campo aberto.", 50)
            else -> Decision("EXPLORAR COM CAUTELA", "Priorizar loot, cobertura e posicionamento.", 30)
        }
    }
}
