# OMEGA AI V0.3 — Android + Termux

## O que foi implementado
- Aplicativo Android nativo Kotlin com bolinha flutuante e chat de dicas locais.
- `SurvivalBrain.kt`: motor de decisões determinístico e testável, com prioridades de safe, vida, kits, inaladores, cobertura, munição, armas, veículo e habilidade defensiva.
- `BrainActivity.kt`: interface para alimentar o cérebro com dados manualmente e executar dois cenários de teste. Funciona offline, sem API.
- Workflow GitHub Actions para tentar compilar o APK e script Termux para publicar em repositório privado.

## Limitações importantes
**NÃO é um bot que joga sozinho no Free Fire original.** Não há captura de tela, detecção visual de inimigos, controle de toque, mira, direção ou partida automática. A autonomia implementada é apenas a escolha da decisão a partir de um estado informado. O código ainda não foi compilado ou testado num Android real. Não há garantia de aprovação pelo anticheat da Garena; contas guest também podem ser banidas.

## Termux (sem PC)
1. Baixe o ZIP e extraia a pasta `OMEGA_AI_Android` em Downloads.
2. `pkg update -y && pkg install git gh unzip -y`
3. `termux-setup-storage` (autorize acesso aos arquivos).
4. `cd ~/storage/downloads/OMEGA_AI_Android`
5. `gh auth login` (autorize pelo navegador).
6. `bash termux/publish.sh`
7. GitHub > repositório `omega-ai-android` > Actions > workflow > artifact `OMEGA-AI-debug-apk`.
8. Extraia o artifact e instale o APK. No Android, autorize sobreposição somente se quiser usar a bolinha.

GitHub Actions tem cotas e depende de acesso ao GitHub. Se a compilação falhar, envie o log de Actions. Nunca envie tokens ou senhas.
