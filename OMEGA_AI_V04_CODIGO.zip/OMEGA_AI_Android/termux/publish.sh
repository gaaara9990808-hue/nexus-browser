#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
if ! command -v gh >/dev/null; then echo 'Instale: pkg install gh git -y'; exit 1; fi
if ! gh auth status >/dev/null 2>&1; then echo 'Faça login: gh auth login'; exit 1; fi
cd "$(dirname "$0")/.."
git init
git branch -M main
git add .
git -c user.name='OMEGA Builder' -c user.email='omega@localhost' commit -m 'Initial Android build' || true
if ! git remote get-url origin >/dev/null 2>&1; then
  gh repo create omega-ai-android --private --source=. --remote=origin --push
else
  git push -u origin main
fi
echo 'Abra GitHub > omega-ai-android > Actions > Build OMEGA Android APK > Artifacts.'
